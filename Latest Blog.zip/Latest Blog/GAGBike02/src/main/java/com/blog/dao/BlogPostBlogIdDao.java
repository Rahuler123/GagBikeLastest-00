package com.blog.dao;

import com.blog.model.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostBlogIdDao {

    @PersistenceContext
    private EntityManager em;
    
    
    @Transactional
    public BlogPost getBlogId(long blogId) {
    	  //TypedQuery<BlogPost> query = em.createQuery("SELECT c FROM BlogPost c ", BlogPost.class);
    		 // List<BlogPost> results = query.getResultList();
    		
    		  String queryStr =
    			      "SELECT c FROM BlogPost c  where c.blogId = :blogId";
    		  
    		  TypedQuery<BlogPost> query =
    			      em.createQuery(queryStr, BlogPost.class);
    			//  List<BlogPage> results = query.getResultList();
    		  BlogPost results = query.setParameter("blogId", blogId).getSingleResult(); 
    			  return results;
    	//	  return results;
    }
	
}
