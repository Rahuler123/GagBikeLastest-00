package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostDeleteCommentDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void deleteChildComment(long blogId,long childId) {
    	
    	Query qry= em.createQuery("DELETE FROM BlogPostChildComment AS t1 WHERE t1.blogId = :blogId AND t1.childId=:childId" );
    	qry.setParameter("blogId" ,blogId);
    	qry.setParameter("childId" ,childId);
	    qry.executeUpdate();
	    }
    
    

//    @Transactional
//    public void deleteChildCommentCount(long blogId) {
//    	Query query2= em.createQuery("UPDATE BlogPost t1 SET t1.replyCount = t1.replyCount-1  WHERE t1.blogId = :blogId");
//		  query2.setParameter("blogId", blogId);
//	       query2.executeUpdate();
//	       }
//    
    
    @Transactional
    public void deleteParentComment(long blogId,long parentId) {
    	
    	Query qry= em.createQuery("DELETE FROM BlogPostParentComment AS t1 WHERE t1.blogId = :blogId AND t1.parentId=:parentId" );
    	qry.setParameter("blogId" ,blogId);
    	qry.setParameter("parentId" ,parentId);
	    qry.executeUpdate();
	    }
}
