package com.blog.dto;

public class BlogPostAuthFlagUpdateRequestDto {
	
	private long userId;
	private long blogId;
	private String authFlag;
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public String getAuthFlag() {
		return authFlag;
	}
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	public BlogPostAuthFlagUpdateRequestDto() {
		
	}
	public BlogPostAuthFlagUpdateRequestDto(long userId, long blogId, String authFlag) {
		super();
		this.userId = userId;
		this.blogId = blogId;
		this.authFlag = authFlag;
	}

}
