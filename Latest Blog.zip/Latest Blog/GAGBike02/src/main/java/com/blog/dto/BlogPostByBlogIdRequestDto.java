package com.blog.dto;

import lombok.Data;

@Data
public class BlogPostByBlogIdRequestDto {
	
	private long blogId;

	public long getBlogId() {
		return blogId;
	}

	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}

	public BlogPostByBlogIdRequestDto() {
	}
	
	public BlogPostByBlogIdRequestDto(long blogId) {
		super();
		this.blogId = blogId;
	}
	

}
