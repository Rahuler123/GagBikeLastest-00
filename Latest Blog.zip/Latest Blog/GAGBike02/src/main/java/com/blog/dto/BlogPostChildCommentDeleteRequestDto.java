package com.blog.dto;

public class BlogPostChildCommentDeleteRequestDto {
	
	private long blogId;
	private long childId;
	
	
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getChildId() {
		return childId;
	}
	public void setChildId(long childId) {
		this.childId = childId;
	}
	public BlogPostChildCommentDeleteRequestDto(long blogId, long childId) {
		super();
		this.blogId = blogId;
		this.childId = childId;
	}
	

	

}
