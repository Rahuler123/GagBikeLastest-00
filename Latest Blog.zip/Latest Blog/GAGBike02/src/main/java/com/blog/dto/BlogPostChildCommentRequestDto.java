package com.blog.dto;

public class BlogPostChildCommentRequestDto {
	
	
	private long blogId;
	private long userId;
	private long parentId;
	private String childContent;
	
	
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getParentId() {
		return parentId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public String getChildContent() {
		return childContent;
	}
	public void setChildContent(String childContent) {
		this.childContent = childContent;
	}
	public BlogPostChildCommentRequestDto() {
		
	}
	public BlogPostChildCommentRequestDto(long blogId, long userId, long parentId, String childContent) {
		super();
		this.blogId = blogId;
		this.userId = userId;
		this.parentId = parentId;
		this.childContent = childContent;
	}

	
}
