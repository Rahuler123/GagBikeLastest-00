package com.blog.dto;

public class BlogPostLikeRequestDto {
	
	private long blogId;
	private long userId;
	
	
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	public BlogPostLikeRequestDto() {
		
	}
	public BlogPostLikeRequestDto(long userId,long blogId) {
		super();
		this.userId = userId;
		this.blogId = blogId;
		
	}
	

}
