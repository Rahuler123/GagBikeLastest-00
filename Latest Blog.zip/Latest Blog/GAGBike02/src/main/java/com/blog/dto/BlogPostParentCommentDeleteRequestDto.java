package com.blog.dto;

public class BlogPostParentCommentDeleteRequestDto {
	
	private long blogId;
	private long parentId;
	
	
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getParentId() {
		return parentId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public BlogPostParentCommentDeleteRequestDto(long blogId, long parentId) {
		super();
		this.blogId = blogId;
		this.parentId = parentId;
	}
	
	

}
