package com.blog.dto;

public class BlogPostParentCommentRequestDto {
	
	private long blogId;
	private long userId;
	private String parentContent;
	
	
	
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getParentContent() {
		return parentContent;
	}
	public void setParentContent(String parentContent) {
		this.parentContent = parentContent;
	}
	
	public BlogPostParentCommentRequestDto() {
		
	}
	public BlogPostParentCommentRequestDto(long blogId, long userId, String parentContent) {
		super();
		this.blogId = blogId;
		this.userId = userId;
		this.parentContent = parentContent;
	}
	
	
}
