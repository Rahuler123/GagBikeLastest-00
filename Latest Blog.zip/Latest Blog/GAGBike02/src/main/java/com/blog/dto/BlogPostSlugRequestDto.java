package com.blog.dto;

import lombok.Data;

@Data
public class BlogPostSlugRequestDto {

	private String slug;
	
	
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	public BlogPostSlugRequestDto(String slug) {
		this.slug = slug;
	}
	public BlogPostSlugRequestDto() {
		
	}
	
	
}
