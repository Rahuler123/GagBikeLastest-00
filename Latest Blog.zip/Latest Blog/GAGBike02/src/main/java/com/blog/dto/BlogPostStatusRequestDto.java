package com.blog.dto;

import lombok.Data;
@Data
public class BlogPostStatusRequestDto {
	
	private long userId;
	private String status;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BlogPostStatusRequestDto(long userId, String status) {
		super();
		this.userId = userId;
		this.status = status;
	}
	

}
