package com.blog.dto;

import lombok.Data;

@Data
public class BlogPostVideosUrlsRequestDto {
	
	
	private  long    blogId;		                                                                     
	private  String  url;
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public BlogPostVideosUrlsRequestDto() {
		
	}
	public BlogPostVideosUrlsRequestDto(long blogId, String url) {
		super();
		this.blogId = blogId;
		this.url = url;
	}
	
	

}
