package com.blog.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.blog.dto.BlogPostSaveRequestDto;
import com.user.model.UserMaster;

import lombok.Data;


@Entity
@Table(name = "blog_Post")
public class BlogPost implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long blogId;
	
//	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY, orphanRemoval =true)
//	@JoinColumn(name ="userId", referencedColumnName = "userId")
//	private UserMaster UserMaster;

	private long userId;
	private long parentId;
	private String title;
	private String metaTitle;
	private String slug;
	private String summary;
	private long published;
	@CreationTimestamp
	private Date createdAt;
	@UpdateTimestamp
	private Date updatedAt;
	@UpdateTimestamp
	private Date publishedAt;
	private long replyCount;
	private long likeCount;
	private long viewCount;
	private String status;
	private String authFlag;
	private String authUser;
	private Date authDate;
	private String content;
	
	
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userId", referencedColumnName = "userId")
	private List<UserMaster> userDetails;
	
	public List<UserMaster> getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(List<UserMaster> userDetails) {
		this.userDetails = userDetails;
	}



	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "blogId", referencedColumnName = "blogId")
	private List<BlogPostLike> LikeType;

	public List<BlogPostLike> getLikeType() {
		return LikeType;
	}
	public void setLikeType(List<BlogPostLike> likeType) {
		LikeType = likeType;
	}
	

	public BlogPost(List<BlogPostLike> likeType,List<UserMaster> userDetails) {
		LikeType = likeType;
		this.userDetails = userDetails;
	}

	
	
	@OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "blogId", referencedColumnName = "blogId")
	@OrderBy("parentId DESC")
    private List<BlogPostParentComment> comments;

	public BlogPost(long blogId, long userId, long parentId, String title, String metaTitle, String slug,
			String summary, long published, Date createdAt, Date updatedAt, Date publishedAt, long replyCount,
			long likeCount, long viewCount, String status, String authFlag, String authUser, Date authDate,
			String content, List<com.blog.model.BlogPostParentComment> comments) {
		super();
		this.blogId = blogId;
		this.userId = userId;
		this.parentId = parentId;
		this.title = title;
		this.metaTitle = metaTitle;
		this.slug = slug;
		this.summary = summary;
		this.published = published;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.publishedAt = publishedAt;
		this.replyCount = replyCount;
		this.likeCount = likeCount;
		this.viewCount = viewCount;
		this.status = status;
		this.authFlag = authFlag;
		this.authUser = authUser;
		this.authDate = authDate;
		this.content = content;
		this.comments = comments;
	}

	public long getBlogId() {
		return blogId;
	}

	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMetaTitle() {
		return metaTitle;
	}

	public void setMetaTitle(String metaTitle) {
		this.metaTitle = metaTitle;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getContent() {
		return content;
	}

	public long getPublished() {
		return published;
	}

	public void setPublished(long published) {
		this.published = published;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getPublishedAt() {
		return publishedAt;
	}

	public void setPublishedAt(Date publishedAt) {
		this.publishedAt = publishedAt;
	}

	public long getReplyCount() {
		return replyCount;
	}

	public void setReplyCount(long replyCount) {
		this.replyCount = replyCount;
	}

	public long getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(long likeCount) {
		this.likeCount = likeCount;
	}

	public long getViewCount() {
		return viewCount;
	}

	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAuthFlag() {
		return authFlag;
	}

	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}

	public String getAuthUser() {
		return authUser;
	}

	public void setAuthUser(String authUser) {
		this.authUser = authUser;
	}

	public Date getAuthDate() {
		return authDate;
	}

	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}

//	public String getContent() {
//		return content;
//	}

	public void setContent(String content) {
		this.content = content;
	}

	

	public List<BlogPostParentComment> getComments() {
		return comments;
	}

	public void setComments(List<BlogPostParentComment> comments) {
		this.comments = comments;
	}

	public BlogPost(BlogPostSaveRequestDto blogPostSaveRequestDto) {
		
		
	}
	public BlogPost() {
		
	}


	public BlogPost(long blogId) {
		this.blogId = blogId;
	}
	public BlogPost(BlogPost blogPost) {
		
		this.createdAt =  new Date();
		this.updatedAt =  new Date();
		this.publishedAt =  new Date();
		this.authDate =  new Date();
	}

	public BlogPost(String summary, String content, String metaTitle, String status, String title, long userId,String slug) {
		this.userId = userId;
		this.title = title;
		this.metaTitle = metaTitle;
		this.slug = slug;
		this.summary = summary;
		this.status = status;
		this.content = content;

	}

	public BlogPost(String slug) {
		this.slug = slug;
	}

	public BlogPost(long userId, long blogId, String status) {
		this.blogId = blogId;
		this.userId = userId;
		this.status = status;
	}
	public BlogPost(long userId, String authFlag, String status) {
		
		this.userId = userId;
		this.authFlag = authFlag;
		this.status = status;
		
	}
	
	

}


