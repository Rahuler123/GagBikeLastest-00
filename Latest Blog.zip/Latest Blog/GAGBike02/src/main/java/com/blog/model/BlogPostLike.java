package com.blog.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "BlogPostLike")
public class BlogPostLike {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long likeId;
	private long parentId;
	private long blogId;
	private long userId;

	//private String title;
	//private long published;
	
	@CreationTimestamp
	private Date createdAt;
	
//	@UpdateTimestamp
//	private Date updatedAt;
//	@UpdateTimestamp
//	private Date publishedAt;
	
	//private long replyCount;
	
	//private long likeCount;
	private long type;
	private String status;
	private String authFlag;
	private String authUser;
//	@UpdateTimestamp
//	private Date authDate;
	
	
	
	
	public BlogPostLike(long likeId, long parentId, long blogId, long userId, Date createdAt, long type, String status,
			String authFlag, String authUser) {
		super();
		this.likeId = likeId;
		this.parentId = parentId;
		this.blogId = blogId;
		this.userId = userId;
		this.createdAt = createdAt;
		this.type = type;
		this.status = status;
		this.authFlag = authFlag;
		this.authUser = authUser;
	}
	public long getBlogId() {
		return blogId;
	}
	public long getUserId() {
		return userId;
	}
	public long getType() {
		return type;
	}
	public void setLikeId(long likeId) {
		this.likeId = likeId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public void setType(long type) {
		this.type = type;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	public void setAuthUser(String authUser) {
		this.authUser = authUser;
	}
	public BlogPostLike() {
		
	}
	
	public BlogPostLike(long userId, long blogId) {
		
		this.userId = userId;
		this.blogId = blogId;
	}
	
	public BlogPostLike(long type) {
		this.type = type;
	}
}
