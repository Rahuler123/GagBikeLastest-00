package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.blog.dao.BlogPostReplyCountUpdateDao;
@Service
public class BlogPostCommentUpdateService {

	@Autowired
	BlogPostReplyCountUpdateDao blogPostReplyCountUpdateDao;
	
	public void updateReplayCount(long blogId){
	   blogPostReplyCountUpdateDao.updateReplayCount(blogId);

	}

}
