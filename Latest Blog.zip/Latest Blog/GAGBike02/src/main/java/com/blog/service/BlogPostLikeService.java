package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostDisLikeCountUpdateDao;
import com.blog.dao.BlogPostLikeCountUpdateDao;
import com.blog.dao.BlogPostDislikeDao;
import com.blog.dao.BlogPostLikeDao;
import com.blog.model.BlogPostLike;
import com.blog.model.BlogVideosUrls;

@Service
public class BlogPostLikeService {
	
	@Autowired
	BlogPostLikeDao blogPostLikeDao;
	
	@Autowired
	BlogPostDislikeDao blogPostDislikeDao;
	
	@Autowired
	BlogPostLikeCountUpdateDao blogPostLikeCountUpdateDao;
	
	@Autowired
	BlogPostDisLikeCountUpdateDao blogPostDisLikeCountUpdateDao;
	
	
	
	public void save(BlogPostLike blogPostLike) {
	
			blogPostLike.setAuthUser("authUser");
			blogPostLike.setAuthFlag("authFlag");
			blogPostLike.setType(1);
			blogPostLike.setParentId(1);
			blogPostLike.setStatus("A");
			blogPostLikeDao.save(blogPostLike);
			blogPostLikeCountUpdateDao.updateLikeCount(blogPostLike.getBlogId());
			
		}
	
	public void updateBlogPostDislike(BlogPostLike blogPostLike) {
		blogPostDislikeDao.updateBlogPostDislike(blogPostLike.getUserId(),blogPostLike.getBlogId());
		blogPostDisLikeCountUpdateDao.updateDisLikeCount(blogPostLike.getBlogId());
		blogPostLikeCountUpdateDao.updateLikeCount(blogPostLike.getBlogId());
	}

//	public long disLikeCountReturn(BlogPostLike blogPostLike) {
//		 blogPostDisLikeCountUpdateDao.disLikeCountReturn(blogPostLike.getBlogId());
//		 return disLikeCountReturn(blogPostLike);
//	}

	
	
}





////System.out.println("userid--- "+blogPostLike.getUserId()  + "blogid----" +blogPostLike.getBlogId());
//long likeString = sampleForLike.sampleForLike(blogPostLike.getUserId(),blogPostLike.getBlogId());
////System.out.println("likeString---"+likeString);
//System.out.println("ELSE STATMENT" +likeString);
//
//if(likeString != 1){
//	
//
//
