package com.blog.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostRecentPageDao;
import com.blog.model.BlogPost;


@Service
public class BlogPostSaveService {

	@Autowired
	BlogPostRecentPageDao BlogPostRecentPageDao;
	
	@Autowired
	BlogPostTotalCountService blogPostTotalCountService;
	
	public void save(BlogPost blog) throws  IOException {
		blog.setCreatedAt(new Date());
		blog.setUpdatedAt(new Date());
		blog.setPublishedAt(new Date());
		blog.setAuthDate(new Date());
		blog.setAuthFlag("P");
		blog.setAuthUser("authUser");
		blog.setParentId(1);

		BlogPostRecentPageDao.save(blog);
		blogPostTotalCountService.updateBlogPostCount(blog.getUserId());
	}

	public ArrayList<BlogPost> selectAll() {
		ArrayList<BlogPost> al = new ArrayList<BlogPost>();
		al.addAll( (Collection<? extends BlogPost>) BlogPostRecentPageDao.findAll());
		return al;
	}
	
}
