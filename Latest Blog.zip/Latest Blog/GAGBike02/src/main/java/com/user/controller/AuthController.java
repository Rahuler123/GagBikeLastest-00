package com.user.controller;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.model.ERole;
import com.user.model.Role;
import com.user.model.UserLogin;
import com.user.model.UserLoginRoless;
import com.user.dto.JwtResponseDto;
import com.user.dto.MessageResponseDto;
import com.user.dto.RoleUpdationRequestDto;
import com.user.dao.RoleRepository;
import com.user.dao.SampleUserRoleUpdation;
import com.user.dao.UserRepository;
import com.user.dto.LoginRequestDto;
import com.user.dto.SignupRequestDto;
import com.blog.dto.BlogPostVideosUrlsRequestDto;
import com.blog.model.BlogVideosUrls;
import com.user.config.JwtUtils;
import com.user.service.ProfileByEmailService;
import com.user.service.SampleUserRepositoryService;
import com.user.service.UserDetailsImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/user")
@Api(value ="JWT Controller")
public class AuthController {
	private static final String String = null;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtUtils jwtUtils;
	
	@Autowired
	SampleUserRepositoryService sampleUserRepositoryService;
	
	@Autowired
	SampleUserRoleUpdation sampleUserRoleUpdation;
	
	@Autowired
	ProfileByEmailService profileByEmailService;
	

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequestDto loginRequest) {
		
		if (!userRepository.existsByEmail(loginRequest.getEmail())) {
			return ResponseEntity.ok(new MessageResponseDto("Login failed ! Couldn't find your email !"));
		}
		
		else {
		
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateJwtToken(authentication);
		
		UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();		
		List<String> roles = userDetails.getAuthorities().stream()
				.map(item -> item.getAuthority())
				.collect(Collectors.toList());
		
	
		return ResponseEntity.ok(new JwtResponseDto(jwt, 
												 userDetails.getId(), 
												 userDetails.getEmail(),
												 roles,
												 profileByEmailService.getByPrimaryEmail(userDetails.getEmail())));
		}
		
	}


	@PostMapping("/signup")
    @ApiOperation(value = "new user signup",response = ResponseEntity.class)
	@ApiResponses(    
			@ApiResponse(code = 200, message = "Successfully retrieved list"))
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequestDto signUpRequest) {

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponseDto("Error: Email is already in use!"));
		}
		
		// Create new user's account
		UserLogin userLogin = new UserLogin(signUpRequest.getEmail(),
							 encoder.encode(signUpRequest.getPassword()),signUpRequest.getPrimaryMobile(),signUpRequest.getStatus());
		
		

		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		if (strRoles == null) {
			Role userRole = roleRepository.findByName(ERole.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			roles.add(userRole);
		} else {
			strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);

					break;
				case "mod":
					Role modRole = roleRepository.findByName(ERole.ROLE_MODERATOR)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(modRole);

					break;
				default:
					Role userRole = roleRepository.findByName(ERole.ROLE_USER)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(userRole);
				}
			});
		}

		userLogin.setRoles(roles);
		sampleUserRepositoryService.save(userLogin);

		System.out.println("strRoles==========================="+roles);
		System.out.println("strRoles=========================++++++++++++++++++++"+userLogin);
		return ResponseEntity.ok(new MessageResponseDto("User registered successfully!"));
	}
	
	@PostMapping("/roleUpdation")
    @ApiOperation(value = "to update the role of the user",response = ResponseEntity.class)
	public ResponseEntity<?> checkUser(@Valid @RequestBody RoleUpdationRequestDto roleUpdationRequestDto) {

		if (!userRepository.existsByEmail(roleUpdationRequestDto.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponseDto("Sorry Email not found !"));
		}
		
		
		
		Set<String> strRoles = roleUpdationRequestDto.getRole();
		Set<Role> roles = new HashSet<>();
		
		System.out.println("strRoles+++++++++++++++++++++++++++++++++++++++"+strRoles);
		
		if(strRoles != null){
			strRoles.forEach(role -> {
				switch (role) {
				case "admin":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(adminRole);

					break;
				case "mod":
					Role modRole = roleRepository.findByName(ERole.ROLE_MODERATOR)
							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					roles.add(modRole);

					break;
//				default:
//					Role userRole = roleRepository.findByName(ERole.ROLE_USER)
//							.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
//					roles.add(userRole);
				}
			});
		}
		UserLogin userLogin = new UserLogin(roleUpdationRequestDto.getEmail());
		userLogin.setRoles(roles);
		sampleUserRoleUpdation.updateRole(roleUpdationRequestDto.getEmail(),roleUpdationRequestDto.getRole());
		System.out.println("strRoles+++++++++++++++++++++++++++++++++++++++"+roles);
		//sampleUserRepository.updateRoles(userLogin);
		
		
		
		
		
		
	return ResponseEntity.ok(new MessageResponseDto("Updated the role - pending !"));
	}
	
	
	@PostMapping(path = "/ROLEUPDATION")
	@ApiOperation("role updation")
	public String roleUpdation(@RequestBody RoleUpdationRequestDto roleUpdationRequestDto) throws IOException  {
		//UserLoginRoless UserLog = new UserLoginRoless(roleUpdationRequestDto.get
		sampleUserRoleUpdation.updateRole(roleUpdationRequestDto.getEmail(), roleUpdationRequestDto.getRole());
		return "Updated ";
	}
	
}
