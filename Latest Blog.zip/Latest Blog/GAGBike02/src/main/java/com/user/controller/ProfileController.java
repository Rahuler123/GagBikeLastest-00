package com.user.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.user.service.ProfileUpdatingService;

import io.swagger.annotations.ApiOperation;

import com.blog.model.BlogPost;
import com.user.dto.UserProfileDto;
import com.user.dto.UserProfileUpdationRequest;
import com.user.model.UserMaster;



@RestController
//@RequestMapping("/blog/details")
@CrossOrigin("*")
public class ProfileController {
	private final ProfileUpdatingService ProfileUpdatingService;
	
	@Autowired
	public ProfileController(ProfileUpdatingService ProfileUpdatingService) {
		this.ProfileUpdatingService = ProfileUpdatingService;
	}
	
//	@GetMapping
//	public ResponseEntity<List<MobileNumber>> findAll() {
//		return ResponseEntity.ok(MobileNumberService.findAll());
//	}
	
	
	
	

	
//	
//	@GetMapping("/{id}")
//	public ResponseEntity <UserMaster> findById(@PathVariable Long id){
//		 return ResponseEntity.ok(ProfileUpdatingService.findByUserId(id).get());
//		 
//	}
	
	
	@PostMapping("/profile/userDetails")
	@ApiOperation("Profile")
	public  Optional<UserMaster> getProfile(@RequestBody UserProfileDto userProfileDto) {
		return ProfileUpdatingService.findByUserId(userProfileDto.getUserId());	
		
	}
	
	
//	@PostMapping("/profile/{primaryEmail}")
//	@ApiOperation("Profile")
//	public  Optional<UserMaster> getProfileByEmail(@RequestBody UserProfileDto userProfileDto) {
//		return ProfileUpdatingService.getPrimayEmail(userProfileDto.getPrimaryEmail());
//		
//	}
	
	
	@PostMapping("/profile/saveProfile")
	 public ResponseEntity <UserMaster> create (@RequestBody UserMaster UserMaster){
		 return ResponseEntity.status(HttpStatus.CREATED).body(ProfileUpdatingService.save(UserMaster));
		 }
//	
//	@PutMapping("profile/updateProfile")
//	public Boolean update ( @RequestBody UserMaster UserMaster){
//		 ResponseEntity.accepted().body(ProfileUpdatingService.update(UserMaster));
//		 return true;
//	}
//	
	
	@PutMapping(path="profile/updateProfile")
	public @ResponseBody Boolean updateUser(@RequestBody UserProfileUpdationRequest profileUpdation) {
		
		UserMaster usrMstr = new UserMaster(profileUpdation.getUserId(),profileUpdation.getFirstName(),profileUpdation.getMiddleName(),profileUpdation.getLastName(),profileUpdation.getPrimaryMobile(),profileUpdation.getSecondaryMobile(),profileUpdation.getPrimaryEmail(),profileUpdation.getSecondaryEmail(),profileUpdation.getAddress1(),profileUpdation.getAddress2(),profileUpdation.getStreetName(),profileUpdation.getStateCode(),profileUpdation.getDistrictCode(),profileUpdation.getPinCode(),profileUpdation.getAddDate(),profileUpdation.getIntro(),profileUpdation.getProfile(),profileUpdation.getGender(),profileUpdation.getProfessionCode());
		ProfileUpdatingService.save(usrMstr);
	    return true; 
	    }
	
	
	
	@DeleteMapping("profile/deleteProfile/{userId}")
	public ResponseEntity delete(@PathVariable Long userId) {
		ProfileUpdatingService.deleteById(userId);
		return ResponseEntity.accepted().build();
		
	}
	
	
}
