package com.user.dao;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.user.model.Role;
@Repository
public class SampleUserRoleUpdation {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateRole(String email, Set<String> role) {
    	
    	Query qry= em.createQuery("insert into user_login_roles (role_id,userId) select (a.id,b.id) from UserLogin AS a JOIN Role AS b  where a.email = :email AND b.name = :role");
    	
    	
    	
    	//Query qry= em.createQuery("update UserLoginRoless  set roleId = (select r.id from Roles as r where r.name =:role) where userId = (select u.id from UserLogin as u where u.email = :email)");
    	//update UserLoginRoles  set roleId = (select id from roles where name =:role) where userId = (select id from userLogin where email = :email)

  //  	insert into UserLoginRoles  (userId,roleId) select a.id,b.id from userLogin AS a JOIN roles AS b  ON a.email = :email AND b.name = :role
	    	qry.setParameter("email", email);
	    	qry.setParameter("role", role);
		    qry.executeUpdate();
		    
	
    }
}
