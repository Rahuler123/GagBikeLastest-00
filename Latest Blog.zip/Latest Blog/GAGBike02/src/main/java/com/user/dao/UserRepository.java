package com.user.dao;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.blog.model.BlogPost;
import com.user.model.UserLogin;

@Repository
public interface UserRepository extends JpaRepository<UserLogin, Long> {
	
	Optional<UserLogin> findByEmail(String email);
	
	Boolean existsByEmail(String email);
	


}
