package com.user.dto;

import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


public class RoleUpdationRequestDto {

    @NotBlank
    @Size(max = 50)
    @Email
    private String email;
    
    private Set<String> role;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<String> getRole() {
		return role;
	}

	public void setRole(Set<String> role) {
		this.role = role;
	}

	public RoleUpdationRequestDto(String email, Set<String> role) {
		this.email = email;
		this.role = role;
	}
    
    
    
    
}