package com.user.dto;

import lombok.Data;

@Data
public class UserProfileDto {
	
	private long userId;

}
