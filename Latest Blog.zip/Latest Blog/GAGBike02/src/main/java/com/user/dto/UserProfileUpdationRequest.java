package com.user.dto;

import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Data
public class UserProfileUpdationRequest {

	private long userId ;
	private String firstName;
	private String middleName;
	private String lastName;
	private long primaryMobile;
	private long secondaryMobile;
	private String primaryEmail;
	private String secondaryEmail;
	private String Address1;	
	private String Address2;	
	private String streetName;
	private String stateCode;	
	private String districtCode;
	private long pinCode;
	@UpdateTimestamp
	private Date addDate;
	private String intro;
	private String profile;
	private String	gender;
	private String	professionCode;
	
}