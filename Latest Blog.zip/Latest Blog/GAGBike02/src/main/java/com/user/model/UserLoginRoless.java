package com.user.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Table(name = "user_login_roles")
public class UserLoginRoless  {
	private int userId;
	private int roleId;
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	
	
	public UserLoginRoless() {
		
	}
	public UserLoginRoless(int userId, int roleId) {
		this.userId = userId;
		this.roleId = roleId;
	}

	
	
	

}
