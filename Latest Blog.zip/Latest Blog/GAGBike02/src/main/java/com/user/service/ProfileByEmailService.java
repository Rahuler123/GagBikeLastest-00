package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.ProfileByEmail;
import com.user.model.UserMaster;

@Service
public class ProfileByEmailService {
	
	@Autowired
	ProfileByEmail profileByEmail;
	
	 public List<UserMaster> getByPrimaryEmail(String primaryEmail) {
		return profileByEmail.getByPrimaryEmail(primaryEmail);
		 
	 }
	

}
