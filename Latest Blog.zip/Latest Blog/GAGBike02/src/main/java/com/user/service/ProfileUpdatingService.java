package com.user.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.user.service.ProfileUpdatingService;
import com.user.model.UserMaster;
import com.user.dao.ProfileUpdatingDao;


@Service
public class ProfileUpdatingService {
	
	private final ProfileUpdatingDao profileUpdatingDao;
	
	
	@Autowired
	public ProfileUpdatingService (ProfileUpdatingDao profileUpdatingDao ) {
		this.profileUpdatingDao = profileUpdatingDao;
		
	}
//	public List<MobileNumber> findAll(){
//		return mobrepo.findAll();
//	}
//	
	public Optional<UserMaster> findByUserId(Long userId){
		return profileUpdatingDao.findById(userId);
		
	}
	 
	public UserMaster save (UserMaster UserMaster) {
		return profileUpdatingDao.save(UserMaster);
	}
	
	public void deleteById(Long userId) {
		profileUpdatingDao.deleteById(userId);
		
	}
	
	
	
	
	

}
