package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.UserRepository;

@Service
public class RoleUpdationService {
	
	@Autowired
	UserRepository userRepository;
	
	

}
