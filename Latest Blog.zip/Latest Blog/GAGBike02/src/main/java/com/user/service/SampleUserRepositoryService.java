package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.UserRepository;
import com.user.model.UserLogin;

@Service
public class SampleUserRepositoryService {
	
	@Autowired
	UserRepository userRepository;
	
//	public void updateRoles(UserLogin userLogin) {
//		userRepository.update(userLogin);
//	 }

	public void save(UserLogin userLogin) {
		userRepository.save(userLogin);
		
	}
	
	

}
